package message;

public class CurrentClientsMessage {
	
}
