package message;

public class EmptyChatMessage {

}
