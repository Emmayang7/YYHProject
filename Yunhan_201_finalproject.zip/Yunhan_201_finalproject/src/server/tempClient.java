package server;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class tempClient extends Thread {
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private boolean offlineBool= true;

	public tempClient(String hostname, int port) {
		Socket s = null;
		//Scanner scan = null;
		try {
			s = new Socket(hostname, port);
			// accepted connection, otherwise get a io exception
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			this.start();
			/*scan = new Scanner(System.in);
			while (true) {
				String line = scan.nextLine();
				ChatMessage message = new ChatMessage("Prof.Miller", line);
				oos.writeObject(message);
				oos.flush();
			}*/

		} catch (IOException ioe) {
			//System.out.println("ioe: " + ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				if (s != null) {
					s.close();
				}
			} catch (IOException ioe) {
				//System.out.println("ioe: " + ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}

	public void run() {
		
			System.out.println("HAHA");
	
		/*try {
			while (true) {
				ChatMessage message = (ChatMessage) ois.readObject();
				System.out.println(message.getName() + ": " + message.getMessage());
			}
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} *//*catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}*/

	}

	public static void main(String args[]) {
		new tempClient("localhost", 6789); //192.168 -->private 
		//not on campus 
	}
}
