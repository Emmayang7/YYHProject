#yunhan yang twitter data logging file
#Partial refers from Tweepy example https://github.com/tweepy/tweepy/blob/master/examples/streaming.py
from __future__ import absolute_import, print_function

import tweepy
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import csv

#Yunhan's twitter API secret key
consumer_key='JwrHI1uge4A6FDjgSyFFlab8X'
consumer_secret='wXI2hh6njEYs1ua2qPUuSUYad3ZMzD2gTnHIIRiblMt06iACau'

access_token='1046487538041581568-6EHcakRuX1TetUZpkqygsnuA3nZRWa'
access_token_secret='5JSQnq16ayRRIGBoIALymDzHXPYip4hMu1P0fHVmAA4Oj'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth,wait_on_rate_limit=True)
#####United Airlines
# Open/Create a file to append data
csvFile = open('1017Nike.csv', 'a')
#Use csv Writer
csvWriter = csv.writer(csvFile)

for tweet in tweepy.Cursor(api.search,q="#Nike",count=10000,
                           lang="en",
                           since="2018-03-01").items():
    print (tweet.created_at, tweet.text)
    csvWriter.writerow([tweet.created_at, tweet.text.encode('utf-8')])

#streaming data logging code 
'''
class TwitterStreamListener(StreamListener):
    print("In listener")
    def on_data(self, data):
        print(data)
        with open('TwitterData_1017.csv', 'a') as tf:
            tf.write(data)
        return True

    def on_error(self, status):
        print("Error Message " + str(status))

if __name__ == '__main__':
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    l = TwitterStreamListener()

    stream = Stream(auth, l)
    stream.filter(languages=["en"], track=['jessica alba']) #select the tweets relate to politics 
    
    ###this contain get recent public twitters
    api = tweepy.API(auth)
    public_tweets = api.home_timeline()
    for tweet in public_tweets:
        print(tweet.text) '''
