/*
 * MatrixSaver.h
 *
 *  Created on: Jul 25, 2016
 *      Author: root
 */

//存矩阵，纪录1的个数和在字典中的位置
#ifndef MATRIXSAVER_H_
#define MATRIXSAVER_H_

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <opencv/cvaux.h>
#include<opencv2/core.hpp>
#include<opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>

#include <stdlib.h>
#include <stdio.h>
#include<stdlib.h>
#include <string.h>

#include <fstream>
#include <string>
#include <iostream>

////
#include "CvxText.h"
#include <time.h>
#include <stdio.h>
#include <iostream>
#include <chrono>
#include <thread>
#include <utility>
#include <functional>
#include <atomic>
#include <vector>

using namespace std;

class MatrixSaver {
public:
	MatrixSaver();
	MatrixSaver(int hcut,int wcut);
	virtual ~MatrixSaver();
	void setMatrix(int hcut, int wcut);
	void addelement(int col, int row, int val); //在矩阵内更改加入整数值
	void deleteelement(int col, int row);//在矩阵内删除加入整数值
	void printmatrix(); //打印矩阵
	void addOneCount(); //纪录1的个数
	int getOneCount(); //返还矩阵1的个数
	void setXpos(int m); //设置行位置
	int getXpos(); //返还行位置位置
	void setYpos(int n); //设置列位置
	int getYpos(); //返还列位置位置
	int ** getMatrix(); //返还矩阵

private:
	int **SingleMatrix;
	int hcut1;
	int wcut1;
	int onecount;
	int xpos;
	int ypos;
};

#endif /* MATRIXSAVER_H_ */
