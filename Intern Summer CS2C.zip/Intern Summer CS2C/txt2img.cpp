//文本转图片， 图片识字转文本程序
// YYH Emma 08/12/16
//opencv library
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <opencv/cvaux.h>
#include<opencv2/core.hpp>
#include<opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "cv.h"
#include "highgui.h"
#include "cxcore.h"

//standard include
#include <stdlib.h>
#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include <fstream>
#include <string>
#include <iostream>
#include <time.h>
#include <chrono>
#include <thread>
#include <utility>
#include <functional>
#include <atomic>
#include <vector>
#include <map>

//中文宽字符
#include <wchar.h>
#include <locale.h>

//自创存矩阵类class
#include "MatrixSaver.h"

//输入中文类class
#include "CvxText.h"


using namespace std;
#pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")

//所输入文本转化图
//二值转化所需过渡图
IplImage *g_pGrayImage = NULL;
//最终二值图
IplImage *g_pBinaryImage = NULL;
const char *pstrWindowsBinaryTitle = "";

//所输入中文字典转化图
//二值转化所需过渡图
IplImage *myg_pGrayImage = NULL;
//最终二值图
IplImage *myg_pBinaryImage = NULL;
const char *mypstrWindowsBinaryTitle = "";

//所自创文本，字典图片转 01矩阵 存储变量
MatrixSaver ** saver;
MatrixSaver ** DictionMap;

//滑动条
void on_trackbar(int pos){
    // 转为二值图
    cvThreshold(myg_pGrayImage, myg_pBinaryImage, pos, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
    // 显示二值图
    cvShowImage(mypstrWindowsBinaryTitle, myg_pBinaryImage);

}

void srcon_trackbar(int pos){
    // 转为二值图
    cvThreshold(g_pGrayImage, g_pBinaryImage, pos, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);
    // 显示二值图
   cvShowImage(pstrWindowsBinaryTitle, g_pBinaryImage);

}

MatrixSaver** GetDictionMap(IplImage *g_pBinaryImage, int maxcol, int rownum, int fontsize){

	    int long i=0;
	    int long j =0;
	    int long k =0;

	    if(g_pBinaryImage == NULL){
	    	cout << "the graph is empty" << endl;
	    }
	     int height1   = g_pBinaryImage->height;
	     int width1    = g_pBinaryImage->width;
	     int step1      = g_pBinaryImage->widthStep;
	     int channels  = g_pBinaryImage->nChannels;
	     unsigned char* dataBinary=(unsigned char*)g_pBinaryImage->imageData;

	     cvMoveWindow("mainWin", height1, width1);

	    IplImage* img =cvCloneImage(g_pBinaryImage);
	    //set to white all img4 data
	    cout << height1 << " " << width1 << " img " << img->height << " " << img->width << " g_pBinaryImage " << g_pBinaryImage->height << " " << g_pBinaryImage->width <<  endl;

	    for(i=0;i<img->height;i++)
	      {
	        for(j=0;j<img->width;j++)
	        {
	            img->imageData[i*step1+j]=255;
	        }
	      }

	    //int AllData[g_pBinaryImage->height][g_pBinaryImage->width];

	    //下面是 2d数组的大小申请 方式overflow
           int **AllData;
	    AllData=(int **)malloc(g_pBinaryImage->height*sizeof(int *));
	    for(int ic=0;ic<g_pBinaryImage->height;ic++)
	            AllData[ic]=(int *)malloc(g_pBinaryImage->width*sizeof(int));


	      for(i=0;i<g_pBinaryImage->height;i++)
	      {
	        for(k=0,j=0;j<g_pBinaryImage->width;j++)
	        {

	            if(dataBinary[i*step1+j]==0)
	            {
	          	  g_pBinaryImage->imageData[i*step1+k]=0;
	          	 //cout<< "1";
	          	  AllData[i][j]= 1;
	             k++;
	            }else{
	          	  //cout <<"0";
	          	  AllData[i][j]= 0;
	            }

	         }
	        //cout << endl;
	      }

	    MatrixSaver **MMsaver; //how many big matrix
	    MMsaver = new MatrixSaver *[rownum];
	    for(i=0;i< rownum;i++) //testing
	        {
	        MMsaver[i] = new MatrixSaver[maxcol];
	        for(int long j=0; j< maxcol; j++){
	      	  MMsaver[i][j].setMatrix( fontsize,  fontsize);
	        }
	    }

	   int hcount=0;
	   int wcount=0;

	  while(hcount != rownum){
	      	while(wcount != maxcol){
	      	 for(int p=0;p<  fontsize;p++){
	      	         for(int q = 0;q<  fontsize;q++) //pos in the certain word matrix
	      	             {
	      	        	      int val =AllData[hcount* fontsize + p][wcount* fontsize +q];
	                            MMsaver[hcount][wcount].addelement(p,q, val);
	                            if(val == 1){
	                          	  MMsaver[hcount][wcount].addOneCount();
	                            }
	      	             }
	      	     }
	      	MMsaver[hcount][wcount].setXpos(wcount);
	      	MMsaver[hcount][wcount].setYpos(hcount);

	        wcount++;
	      }
	      	      wcount=0;
	      	      hcount++; // add after a line of matrix

				}

	     free(AllData);
	     return MMsaver;
}

//二值图转化为矩阵
MatrixSaver ** Binary2Matrix(IplImage *g_pBinaryImage, int maxcol, int rownum, int fontsize){

    int i=0;
    int j =0;
    int k =0;

    if(g_pBinaryImage == NULL){
    	cout << "the graph is empty" << endl;
    }
     int height1   = g_pBinaryImage->height;
     int width1    = g_pBinaryImage->width;
     int step1      = g_pBinaryImage->widthStep;
     int channels  = g_pBinaryImage->nChannels;
     unsigned char* dataBinary=(unsigned char*)g_pBinaryImage->imageData;

     cvNamedWindow("mainWin", CV_WINDOW_AUTOSIZE);
     cvMoveWindow("mainWin", height1, width1);

    IplImage* img =cvCloneImage(g_pBinaryImage);
    //set to white all img4 data
    for(i=0;i<img->height;i++)
      {
        for(j=0;j<img->width;j++)
        {
            img->imageData[i*step1+j]=255;
        }
      }

    // int AllData[g_pBinaryImage->height][g_pBinaryImage->width];

        int **AllData2;
 	    AllData2=(int **)malloc(g_pBinaryImage->height*sizeof(int *));
 	    for(int ic=0;ic<g_pBinaryImage->height;ic++)
 	    AllData2[ic]=(int *)malloc(g_pBinaryImage->width*sizeof(int));

      for(i=0;i<g_pBinaryImage->height;i++)
      {
        for(k=0,j=0;j<g_pBinaryImage->width;j++)
        {
            if(dataBinary[i*step1+j]==0)
            {
          	  g_pBinaryImage->imageData[i*step1+k]=0;
          	 // cout<< "1";
          	  AllData2[i][j]= 1;
             k++;
            }else{
          	  //cout <<"0";
          	  AllData2[i][j]= 0;
            }

         }
        //cout << endl;
      }

    MatrixSaver **Msaver; //how many big matrix
    Msaver = new MatrixSaver *[rownum];
    for(i=0;i< rownum;i++) //testing
        {
        Msaver[i] = new MatrixSaver[maxcol];
        for(int j=0; j< maxcol; j++){
      	  Msaver[i][j].setMatrix( fontsize,  fontsize);
        }
    }

   int hcount=0;
   int wcount=0;

  while(hcount != rownum){
      	while(wcount != maxcol){
      	 for(int p=0;p<  fontsize;p++){
      	         for(int q = 0;q<  fontsize;q++) //pos in the certain word matrix
      	             {
      	        	      int val =AllData2[hcount* fontsize + p][wcount* fontsize +q];
                            Msaver[hcount][wcount].addelement(p,q, val);
                            if(val == 1){
                          	  Msaver[hcount][wcount].addOneCount();
                            }
      	             }
      	     }
      	                     wcount++;

      	   }
      	      wcount=0;
      	      hcount++; // add after a line of matrix

			}

     free(AllData2);
     return Msaver;
}




vector<std::pair <int,int>> getSameOneMatrix(MatrixSaver **DictionMap, int count, int col, int row){
	 //在字典图中找寻和该字一样 “1的个数“ 的汉字或符号
	  //并将其行列位置存入SameOneMatrix中
	vector<std::pair <int,int>> SameOneMatrix;
	             for(int s=0; s < row; s++)
		                     {
		                      for(int f=0; f< col; f++)
		                      {
		                    	   if(DictionMap[s][f].getOneCount()== count){
		                    		   SameOneMatrix.push_back(make_pair(s,f));

		                    	   }
		                      }
		            }

	             return SameOneMatrix;
}


int main(int argc,char *argv[]){

    IplImage *src=NULL;
    IplImage *Mapsrc = NULL;
    char *textname;
    int width,height;
    int R,G,B;
    int x,y;
    int fontsize; //the size of word 分辨率调配
    char *dictioname;
    char *imagename;

    if(argc==8)
    {

     string type = argv[2];
     if(type  == "--txtin"){

          	  textname=argv[3]; //input text
          	  dictioname=argv[7]; //dictionary
          	  imagename = argv[5]; //output image

          	  //打开文档
          	  FILE * file;
          	  file = fopen( textname, "r");
          	  if( file == NULL ){
                perror("Error while opening the file.\n");
                       exit(EXIT_FAILURE);
                    }
          	     //选定字体
                 CvxText text("/usr/share/fonts/MicrosoftYaHei.ttf");

                 wchar_t buf[1000];

                 setlocale(LC_CTYPE,"en.UTF-8");   // put your locale here

                 int maxcol =0;
                 int rownum =0;
                 while (fgetws(buf,1000,file)!=NULL){
                        wprintf(L"%s",buf);
                        if(maxcol< wcslen(buf)){
                       	       maxcol =wcslen(buf);
                       	               }
                         rownum++;
                 }

                 fclose(file);

          	        //自定义的字体大小
          	         fontsize = 64;

          	         //https://start.fedoraproject.org/
          	         //图片汉字的初始位置
          	         x=0;
          	         y=fontsize-1;

          	         //字体颜色
          	         R=255;
          	         G=255;
          	         B=255;

          	         float p = 1;
          	         CvScalar TypeSize = cvScalar(
          	             64,     //字大小
          	             1,      //
          	             0.5,    //
          	             0       //
          	             );
          	         bool bUnderline = true;

          	         text.setFont(NULL, &TypeSize, &bUnderline, &p);

          	         //图片汉字初始点
          	         CvPoint Point = cvPoint(x,y);

          	         //根据字体计算图片大小 ****************修改
          	         width= maxcol *fontsize;
          	         height=rownum *(fontsize+10);

          	         //创造原始空白图片
          	         src = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);

          	         if(!src)
          	             {
          	                    printf("Can not create the image.\n");
          	                    return -1;
          	             }

                    //保证空白图片
          	        cvZero(src);

          	        //在空白图片上一行一行输入文字
          	        FILE * fil;
          	        fil = fopen( textname , "r");
          	               wchar_t buffer[1024];
          	               setlocale(LC_CTYPE,"en.UTF-8");   // put your locale here

          	               while (fgetws(buffer,1024,fil)!=NULL){
          	                      text.putText(src, buffer, cvPoint(x, y), CV_RGB(R,G,B));
          	                      //自动计算下一行纵轴坐标
          	                      y = y+fontsize;
          	                      x = 0;
          	           }

          	               fclose(fil);

          	           //二值化
          	           const char *pstrWindowsSrcTitle ="";
          	           const char *pstrWindowsToolBarName = "";

          	            // 转为灰度图
          	            g_pGrayImage =  cvCreateImage(cvGetSize(src), IPL_DEPTH_8U, 1);
          	            cvCvtColor(src, g_pGrayImage, CV_BGR2GRAY);

          	            // 创建二值图
          	            g_pBinaryImage = cvCreateImage(cvGetSize(g_pGrayImage), IPL_DEPTH_8U, 1);

          	            // 创建二值图窗口
          	            cvNamedWindow(pstrWindowsBinaryTitle, CV_WINDOW_AUTOSIZE);

          	            // 显示原图
          	            cvNamedWindow(pstrWindowsSrcTitle, CV_WINDOW_AUTOSIZE);


          	            // 滑动条
          	            int Threshold = 0;
          	            cvCreateTrackbar(pstrWindowsToolBarName, pstrWindowsBinaryTitle, &Threshold, 254, on_trackbar);

          	            srcon_trackbar(1);

         	  	  	  	cvDestroyWindow(pstrWindowsBinaryTitle);
                        //cvDestroyWindow(pstrWindowsSrcTitle);

         	  	  	  	//存图
                        cvSaveImage(imagename, g_pBinaryImage);

                        cvWaitKey(0);

                        cvReleaseImage(&src);
                        cvReleaseImage(&g_pBinaryImage);
                        cvReleaseImage(&g_pGrayImage);

            }


      if(type == "--txtout"){
                textname=argv[3]; //output text
    	        dictioname=argv[7]; //dictionary
    	        imagename = argv[5]; //input image

    	                    //打开字典文件，算行和列数
    	                    FILE * filed;
    	           	        filed = fopen( dictioname, "r");
    	           	        if( filed == NULL )
    	           	           {
    	           	              perror("Error while opening the file.\n");
    	           	              exit(EXIT_FAILURE);
    	           	           }
    	           	        CvxText mytext("/usr/share/fonts/MicrosoftYaHei.ttf");

    	           	        wchar_t mybuf[1000];

    	           	        setlocale(LC_CTYPE,"en.UTF-8");   // put your locale here

    	           	        int col =0;
    	           	        int row =0;
    	           	        while (fgetws(mybuf,1000,filed)!=NULL){
    	           	               wprintf(L"%s",mybuf);
    	           	               if(col< wcslen(mybuf)){
    	           	              	       col =wcslen(mybuf);
    	           	              	               }
    	           	                row++;

    	           	        }

    	           	        fclose(filed);

    	           	        //自定义的字体大小
    	           	        fontsize = 64;

    	           	        //https://start.fedoraproject.org/
    	           	        //图片汉字的初始位置
    	           	        x=0;
    	           	        y=fontsize-1;

    	           	        //字体颜色
    	           	        R=255;
    	           	        G=255;
    	           	        B=255;

    	           	        float mp = 1;
    	           	        CvScalar mTypeSize = cvScalar(
    	           	            64,     //字大小
    	           	            1,      //
    	           	            0.5,    //
    	           	            0       //
    	           	            );
    	           	        bool mbUnderline = true;

    	           	        mytext.setFont(NULL, &mTypeSize, &mbUnderline, &mp);

    	           	        //图片汉字初始点
    	           	        CvPoint mPoint = cvPoint(x,y);

    	           	        //根据字体计算图片大小
    	           	        width= col *(fontsize*1.5);
    	           	       // width= col *fontsize;
    	           	        height=row *(fontsize+10);

    	           	        //创造原始空白图片
    	           	        Mapsrc = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);

    	           	        if(!Mapsrc)
    	           	            {
    	           	                   printf("Can not create the image.\n");
    	           	                   return -1;
    	           	            }

    	           	      //保证空白图片
    	           	       cvZero(Mapsrc);

    	           	       //在图片上输入字典文字
    	           	       FILE * mfil;
    	           	       mfil = fopen( dictioname , "r");

    	           	              wchar_t mbuffer[1024];

    	           	              setlocale(LC_CTYPE,"en.UTF-8");   // put your locale here

    	           	              while (fgetws(mbuffer,1024,mfil)!=NULL){

    	           	                     mytext.putText(Mapsrc, mbuffer, cvPoint(x, y), CV_RGB(R,G,B));
    	           	                     y = y+fontsize;
    	           	                     x = 0;
    	           	          }

    	           	              fclose(mfil);

                                        //转化二值图
    	           	                    const char *mypstrWindowsSrcTitle ="";
    	           	                    const char *mypstrWindowsToolBarName = "";
    	           	                       // 转为灰度图
    	           	                       myg_pGrayImage =  cvCreateImage(cvGetSize(Mapsrc), IPL_DEPTH_8U, 1);
    	           	                       cvCvtColor(Mapsrc, myg_pGrayImage, CV_BGR2GRAY);

    	           	                       // 创建二值图
    	           	                       myg_pBinaryImage = cvCreateImage(cvGetSize(myg_pGrayImage), IPL_DEPTH_8U, 1);

    	           	                       // 显示原图
    	           	                       cvNamedWindow(mypstrWindowsSrcTitle, CV_WINDOW_AUTOSIZE);

    	           	                       // 创建二值图窗口
    	           	                       cvNamedWindow(mypstrWindowsBinaryTitle, CV_WINDOW_AUTOSIZE);

    	           	                       // 滑动条
    	           	                       int nThreshold = 0;
    	           	                       cvCreateTrackbar(mypstrWindowsToolBarName, mypstrWindowsBinaryTitle, &nThreshold, 254, on_trackbar);

    	           	                   on_trackbar(1);

                              //转换字典每个字为二值图，并将01矩阵存在自创MatrixSaver类里
    	                      DictionMap = GetDictionMap(myg_pBinaryImage, col, row , fontsize);

                              //从文件名获取图片
    	                      src = cvLoadImage(imagename, CV_LOAD_IMAGE_COLOR);

    	                        //二值化
    	                               const char *pstrWindowsSrcTitle ="";
    	                               const char *pstrWindowsToolBarName = "";
    	                                  // 转为灰度图
    	                                  g_pGrayImage =  cvCreateImage(cvGetSize(src), IPL_DEPTH_8U, 1);
    	                                  cvCvtColor(src, g_pGrayImage, CV_BGR2GRAY);

    	                                  // 创建二值图
    	                                  g_pBinaryImage = cvCreateImage(cvGetSize(g_pGrayImage), IPL_DEPTH_8U, 1);

    	                                  // 显示原图
    	                                  cvNamedWindow(pstrWindowsSrcTitle, CV_WINDOW_AUTOSIZE);

    	                                  // 创建二值图窗口
    	                                  cvNamedWindow(pstrWindowsBinaryTitle, CV_WINDOW_AUTOSIZE);

    	                                  // 滑动条
    	                                  int Threshold = 0;
    	                                  cvCreateTrackbar(pstrWindowsToolBarName, pstrWindowsBinaryTitle, &Threshold, 254, on_trackbar);

    	                                  srcon_trackbar(1);


    	                                  int height1   = g_pBinaryImage->height;
    	                                  int width1    = g_pBinaryImage->width;
    	                                  int step1      = g_pBinaryImage->widthStep;
    	                                  int channels  = g_pBinaryImage->nChannels;

    	                                  int maxcol = width1/fontsize;
    	                                  int divide =(fontsize+10);
    	                                  int rownum = height1/74; //10 行间距

    	                                //转换输入图中每个字为二值图，并将01矩阵存在自创MatrixSaver类里
    	                                saver = Binary2Matrix(g_pBinaryImage, maxcol, rownum, fontsize);

    	                                //用于存储存在字在字典文件里的行列位置
    	                                vector< std::pair <int,int> > WordPosTrack; //change line use -2 -2
    	                                //与某词存在相同“1的个数“
    	                               	vector< std::pair <int,int>> SameOneNumMatrix;

    	                                  for(int o=0; o < rownum; o++){
    	                               	   for(int l =0; l < maxcol; l++){
    	                               		   //check through 1 count
    	                               		   int OneC = saver[o][l].getOneCount();
    	                               		   //在字典图中找寻和该字一样 “1的个数“ 的汉字或符号
    	                               		   //并将其行列位置存入SameOneNumMatrix中
    	                               		   SameOneNumMatrix = getSameOneMatrix( DictionMap, OneC, col, row);
    	                                          if(SameOneNumMatrix.size() == 1){ //if only one exist
    	                                       	   WordPosTrack.push_back(make_pair(SameOneNumMatrix[0].first, SameOneNumMatrix[0].second));
    	                                          }
    	                                          else if(SameOneNumMatrix.size() == 0){

    	                                          }
    	                                          else{

    	                                           //该字有多于一个汉字或符号与其有相同  “1的个数“
    	                                       	   //Compare the Matrix itself
    	                                       	   vector<std::pair <int,int>> FirstSort;
    	                                       	   bool judge = true;

    	                                       	   int test =0;
    	                                       	 //一一对比矩阵的01排列
    	                                       	 for(int v=0; v< signed(SameOneNumMatrix.size()); v++){

    	                                       	   for(int ii=0; ii < fontsize; ii++){
    	                                       	            for(int jj=0; jj < fontsize; jj++){

    	                                       	       if((DictionMap[SameOneNumMatrix[v].first][SameOneNumMatrix[v].second].getMatrix())[ii][jj] - (saver[o][l].getMatrix())[ii][jj] != 0){

    	                                       	            	  test++;
    	                                       	    	          judge = false;
    	                                       	                  break;
    	                                       	                  }
    	                                       	             }

    	                                       	       }
    	                                       	   test = 0;

    	                                       	   if(judge == true){
    	                                       	            WordPosTrack.push_back(make_pair(SameOneNumMatrix[v].first, SameOneNumMatrix[v].second));
    	                                       	            break;
    	                                       	           }
    	                                       	   	   judge = true;

    	                                       	   }


    	                                        }

    	                               	   }
    	                               	   WordPosTrack.push_back(make_pair(-2,-2)); //change line
    	                                }

    	                                //print the corresponding word
    	                                                          //根据字节判断汉字，字母，符号并存在二维string组中
    	                                  	   	   	   	   	   	   string ** WordChart;
    	                                                           WordChart = new string *[row];
    	                                                              for(int hh=0;hh< row;hh++) //testing
    	                                                                  {
    	                                                                  WordChart[hh] = new string[col];
    	                                                                }

    	                                                                string t;
    	                                                                string line;
    	                                                                ifstream myfile (dictioname);
    	                                                                int whichline =0;
    	                                                                if (myfile.is_open())
    	                                                                {
    	                                                                  while ( getline (myfile,line) )
    	                                                                  {
    	                                                                    //cout << line << '\n';
    	                                                                    for(int i=0, d=0; i<signed(line.length()); i++)
    	                                                                     {
    	                                                                        if(line[i]<255 && line[i]>0)//扩充的AlineCII字符范围为0-255,如是,处理一个字节
    	                                                                         {
    	                                                                          t = "";
    	                                                                          t.append(line.substr(i,1));
    	                                                                         // cout << "       t is " << t << endl;
    	                                                                          WordChart[whichline][d] = t;
    	                                                                          d++;
    	                                                                         }
    	                                                                         else//<0,>255的是汉字,处理两个字节
    	                                                               {
    	                                                                 t = "";
    	                                                                 t.append(line.substr(i,3));
    	                                                                 WordChart[whichline][d] = t;
    	                                                                // cout << "       t is " << t << endl;
    	                                                                 ++i;
    	                                                                 ++i;
    	                                                                 d++;
    	                                                                }

    	                                                                }
    	                                                                    whichline++;
    	                                                                  }
    	                                                                  myfile.close();
    	                                                                }


    	                                            string result;
    	                                   	         for(int k = 0; k < signed(WordPosTrack.size()); k++)
    	                                   	                   {
    	                                   	                        if(WordPosTrack[k].first !=-2  && WordPosTrack[k].second != -2 && WordPosTrack[k].first !=-1  && WordPosTrack[k].second != -1){ //output[i][i] does no work: no operator [] matches these operands"
    	                                                                // cout << WordChart[WordPosTrack[k].first][WordPosTrack[k].second] << endl;
    	                                   	                        	result += WordChart[WordPosTrack[k].first][WordPosTrack[k].second];
    	                                   	                        }

    	                                   	                        if(WordPosTrack[k].first ==-2  && WordPosTrack[k].second == -2){ //new line
    	                                   	                        	 result += "\n";
    	                                   	                        }

    	                                   	                        if(WordPosTrack[k].first ==-1  && WordPosTrack[k].second == -1){ //blank space
    	                                   	                        	result += " ";
    	                                   	                        }
    	                                   	                   }


    	                                   	           ofstream resultfile;
    	                                   	           resultfile.open (textname);
    	                                   	           resultfile << result;
    	                                   	           resultfile.close();

    	                                   	                             cvDestroyWindow(mypstrWindowsSrcTitle);
    	                                   	            	             cvDestroyWindow(mypstrWindowsBinaryTitle);

    	                                   	           	  	  	  	     cvDestroyWindow(pstrWindowsSrcTitle);
    	                                   	                             cvDestroyWindow(pstrWindowsBinaryTitle);

    	                                   	                             cvDestroyWindow("show");
    	                                   	                             cvReleaseImage(&src);
    	                                   	                             cvReleaseImage(&g_pBinaryImage);
    	                                   	                             cvReleaseImage(&g_pGrayImage);

    	                                   	                             cvDestroyWindow("show");
    	                                   	                             cvReleaseImage(&Mapsrc);
    	                                   	                             cvReleaseImage(&myg_pBinaryImage);
    	                                   	                             cvReleaseImage(&myg_pGrayImage);
      }


        free(saver);
        free(DictionMap);

         cout << "reach here" << endl;
        return 0;
    }

    else{
    cout << "参数不正确或缺失，请输入以下样本命令之一：" << endl;
    cout << "Arguments are missing. Please input either of the following: " << endl;
    cout << endl;
    cout << "文转图 text file to image" << endl;
    cout << "./BB2 txt2img --txtin text.txt --imgout txtimg.png --dir Diction.txt" << endl;
    cout << "图转文 image to text file" << endl;
    cout << "./BB2 txt2img --txtout imagetotxt.txt --imgin txtimg.png --dir Diction.txt" << endl;

    return 0;
    }
}



