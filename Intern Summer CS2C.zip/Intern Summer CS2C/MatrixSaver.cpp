/*
 * MatrixSaver.cpp
 *
 *  Created on: Jul 25, 2016
 *      Author: root
 */

//存矩阵，纪录1的个数和在字典中的位置
#include "MatrixSaver.h"
using namespace std;

MatrixSaver::MatrixSaver(){

}

MatrixSaver::MatrixSaver(int hcut, int wcut) {
	// TODO Auto-generated constructor stub
	hcut1 = hcut;
	wcut1 = wcut;
	onecount =0;
	SingleMatrix = new int*[hcut];
	for(int i = 0; i < hcut; i++){
	    SingleMatrix[i] = new int[wcut];
	     for(int j=0; j< wcut; j++){
	    	 SingleMatrix[i][wcut] = -1;  //the initial value of every pos in matrix is -1
	     }
	}
    xpos =-1;
    ypos =-1;
}

MatrixSaver::~MatrixSaver() {
	// TODO Auto-generated destructor stub
	for(int i = 0; i < hcut1; i++)
       delete []SingleMatrix[i];
	delete []SingleMatrix;

}

void MatrixSaver::setMatrix(int hcut, int wcut) {
	// TODO Auto-generated constructor stub
	hcut1 = hcut;
	wcut1 = wcut;
	onecount =0;
	SingleMatrix = new int*[hcut];
	for(int i = 0; i < hcut; i++){
	    SingleMatrix[i] = new int[wcut];
	     for(int j=0; j< wcut; j++){
	    	 SingleMatrix[i][wcut] = -1;  //the initial value of every pos in matrix is -1
	     }
	}

}

void MatrixSaver::addelement(int col, int row, int val){ //add a matrix
   SingleMatrix[col][row] = val;
  // cout << "MS" << SingleMatrix[col][row];
}

void MatrixSaver::deleteelement(int col, int row){
	SingleMatrix[col][row] = -1;
}

void MatrixSaver::printmatrix(){
	//cout << "why not come out" << hcut1 << " " << wcut1 <<endl;
	for(int i = 0; i < hcut1; i++){
		     for(int j=0; j< wcut1; j++){
		    	 cout << SingleMatrix[i][j];
		     }
		     cout << endl;
		}
}

void MatrixSaver::addOneCount(){
	onecount++;
}

int MatrixSaver::getOneCount(){
	return onecount;
}

void MatrixSaver::setXpos(int m){
	 xpos = m;
}

int MatrixSaver::getXpos(){
	return xpos;
}

void MatrixSaver::setYpos(int n){
	 ypos = n;
}

int MatrixSaver::getYpos(){
	return ypos;
}

int ** MatrixSaver::getMatrix(){
	return SingleMatrix;
}


